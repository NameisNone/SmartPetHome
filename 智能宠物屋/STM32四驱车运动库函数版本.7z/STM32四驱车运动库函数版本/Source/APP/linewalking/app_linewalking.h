/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         bsp_linewalking.h
* @author       liusen
* @version      V1.0
* @date         2015.01.03
* @brief        Ѳ��ģʽͷ�ļ�
* @details      
* @par History  ������˵��
*                 
* version:	liusen_20170717
*/

#ifndef __APP_LINEWALKING_H__
#define __APP_LINEWALKING_H__	


//void app_LineWalking(void);
void deal_with(void);
void app_LineWalking(void);
void app_LineWalking1(float distance)	;	////����ʱ��Ѱ�ߴ���
void app_LineWalking2(void);
void calculate (void);

void banyun(void);
void receive1(void);
void receive2(void);
#endif



