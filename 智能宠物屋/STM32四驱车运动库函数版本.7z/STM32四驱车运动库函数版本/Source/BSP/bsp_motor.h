
#ifndef __BSP_MOTOR_H__
#define __BSP_MOTOR_H__

#include "stm32f10x.h"

#define Motor_RCC		 RCC_APB2Periph_GPIOB
#define Motor_Port		 GPIOB
#define Left_MotoA_Pin 	 GPIO_Pin_9
#define Left_MotoB_Pin 	 GPIO_Pin_8
#define Left_MotoA1_Pin		GPIO_Pin_0
#define Left_MotoB1_Pin 	 GPIO_Pin_1

#define Right_MotoA_Pin	 GPIO_Pin_4
#define Right_MotoB_Pin  GPIO_Pin_5
#define Right_MotoA1_Pin	GPIO_Pin_11
#define Right_MotoB1_Pin  	GPIO_Pin_12


void Motor_PWM_Init(u16 arr, u16 psc, u16 arr2, u16 psc2,u16 arr3, u16 psc3, u16 arr4, u16 psc4 );


#endif
