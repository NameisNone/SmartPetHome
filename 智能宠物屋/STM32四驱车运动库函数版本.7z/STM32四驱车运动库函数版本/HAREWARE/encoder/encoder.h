#ifndef __ENCODER_H
#define __ENCODER_H	 
#include "sys.h" 
void TIM4_Encoder_Init(u16 arr,u16 psc);
void TIM3_Encoder_Init(u16 arr,u16 psc);
float HF_Get_Encode_TIM3(void);
float HF_Get_Encode_TIM4(void);
void get_distance(int distance);
int64_t GeiCurrentPosition(void);
#endif









